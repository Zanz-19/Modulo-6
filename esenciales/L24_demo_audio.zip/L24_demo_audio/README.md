# L24 demo audio

Nine clips, ~3.2 MB, for the L24 demo and for students who arrive without their own recordings.
All assembled from material already in this repo — nothing is fetched at class time, so no
website has to be reachable and Wikimedia cannot rate-limit the room.

## The clips

| File | What it is | CLAP top-1 | Score |
|---|---|---|---|
| `dog.wav` | dog barking | a dog barking | 1.000 |
| `rain.wav` | rain | rain falling | 1.000 |
| `birds.wav` | birdsong | birds chirping | 0.999 |
| `vacuum_cleaner.wav` | vacuum cleaner | a vacuum cleaner | 0.999 |
| `crying_baby.wav` | baby crying | a baby crying | 1.000 |
| `clock_tick.wav` | mechanical clock | a clock ticking | 0.998 |
| `chainsaw.wav` | chainsaw, distant | **a vacuum cleaner** | **0.880** |
| `speech_es.mp3` | Spanish speech, 5 s | a person speaking | 0.980 |
| `speech_en.mp3` | English speech, 5 s | a person speaking | 0.974 |

All five-second mono clips; the two speech files are 5.2 s. Verified 2026-09-18 against
`laion/clap-htsat-unfused` at 48 kHz, with the candidate list

> `a dog barking · rain falling · birds chirping · a vacuum cleaner · a baby crying ·
> a clock ticking · a person speaking`

## `chainsaw.wav` is the interesting one

There is no chainsaw label in that list, so the clip is out of vocabulary. CLAP answers
**"a vacuum cleaner" at 0.880** — and that number is the lesson.

A confidence floor of 0.45, which is what the demo notebook uses, **does not catch this**. The
floor filters clips the model is unsure about; it cannot filter a clip the model is confidently
wrong about, because zero-shot scores are a softmax *over the list you supplied*, not a measure
of whether anything in the list is right at all.

Use it to push back when a student sets their floor and declares the problem solved. The honest
answers are to widen the vocabulary, add an explicit "something else" candidate, or look at the
margin between top-1 and top-2 rather than at top-1 alone.

## Getting them to Drive

The notebooks read from `MyDrive/TAE_IA_M6/inputs/`, the shared folder L11 and L12 already use.
Either drag this folder's contents in through the Drive web UI before class, or run
`upload_inputs()` in the notebook and pick them from the file dialog.

`list_inputs()` prints what is in the folder.

## Provenance and licences

**ESC-50** — Karol J. Piczak, *ESC: Dataset for Environmental Sound Classification*,
Proceedings of the 23rd ACM International Conference on Multimedia, 2015.
<https://github.com/karoldvl/ESC-50/> · dataset licensed **CC BY-NC 3.0**.

The seven sound clips are taken from **fold 5**, which is ESC-50's held-out test split — so the
demo's L17 checkpoint is not being scored on clips it trained on. Per-clip attribution, all from
freesound.org:

| File | Original | Author | Licence |
|---|---|---|---|
| `dog.wav` | Toupie1.mp3 (203128) | Pierre Grandjean | CC0 |
| `rain.wav` | rain.aiff (181766) | laura222 | CC0 |
| `birds.wav` | voice of birds (242490) | moloch777 | CC-BY |
| `vacuum_cleaner.wav` | Vacuum cleaner Bomann 1600 Watt (182007) | ohrpilot | CC0 |
| `crying_baby.wav` | 01 baby crying hard.wav (151085) | PickleJones | CC0 |
| `clock_tick.wav` | Mechanical clock ticking (201194) | opticalnoise | CC-BY |
| `chainsaw.wav` | Chainsaws (distant) (170338) | micadoe | CC0 |

**Speech** — `speech_es.mp3` and `speech_en.mp3` are copied unchanged from
`Labs/assets/L19_audio.zip` (`clear_es.mp3`, `clear_en.mp3`), already used in L19.

`_manifest.tsv` records the original ESC-50 filename for every clip, so any of this can be
traced back.

---

Regenerate with `tools/lab_builders/build_demo_audio.py`.
